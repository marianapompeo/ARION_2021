
<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include('conexao.php');


$nomefantasia=$_POST['nomefantasia'];
$cnpjcei=$_POST['cnpjcei'];
$endereco=$_POST['endereco'];
$cidade=$_POST['cidade'];

$id_usuario=$_SESSION['usuarioId']; 

$sql =        "INSERT INTO `empresa` ";
$sql = $sql . "(`id_usuario`,`nomefantasia`, `cnpjcei`, `endereco`, `cidade`) ";
$sql = $sql . "VALUES ('$id_usuario','$nomefantasia','$cnpjcei','$endereco','$cidade')";

//echo $sql;
//die();
$inserir = mysqli_query($conexao,$sql);

?>

<html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ARION</title>
  <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="assets/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="assets/css/sb-admin.min.css">
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Arsha - v2.3.1
  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.html">ARION</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
<nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="index.html">Página Inicial</a></li>
          <li><a href="#">Sobre o Projeto</a></li>
          <li><a href="#">Dicas de Segurança</a></li>
          <li><a href="#">Time</a></li>
          <li><a href="#">Contato</a></li>

        </ul>
      </nav><!-- .nav-menu -->

      <a href="sair.php" class="get-started-btn scrollto">Sair</a>

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <ol>
          <!--<li><a href="index.html">Home</a></li> -->
          <li>Cadastro de Empresa</li>
        </ol>
        <h2>Cadastro de Empresa</h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page">
      <div class="container">

		<h4> Empresa cadastrada! Volte para Lista de Empresas Cadastradas</h4>
	</div>
	<center>


      
    </section>

  </main><!-- End #main -->

 <div style="text-align: center;">
        <form action="empresa_lista2.php" method="POST" style="margin-top: 20px">
          <div class="form-group">
          <button type="submit" id="botao" class="btn btn-danger botao">Voltar </button>
          <input type="hidden" name="id" value=<?php echo $id_usuario ?> >
          </form>
		
	</center> 
</body>
</html>
