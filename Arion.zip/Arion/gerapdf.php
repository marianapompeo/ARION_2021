<?php
session_start();

//require('./fpdf/fpdf.php');
require('./fpdf/WriteHTML.php');
include('conexao.php');

//$id_ativo= $_POST['id_ativo'] ;

$id_tipo_ativo= $_POST['id_tipo_ativo'] ;
$id_processo= $_POST['id_processo'] ;
$conteudo= $_POST['pdf'] ;
$valor_risco= $_POST['valor_risco'] ;
$descricao_ativo= $_POST['descricao_ativo'] ;
$id_ativo= $_POST['id_ativo'] ;
$id= $_POST['id'] ;
$risco_qualitativo= $_POST['risco_qualitativo'] ;


$pdf=new PDF_HTML();
$pdf->AddPage();
$pdf->SetFont('Arial');
//nome do ativo
$pdf->WriteHTML('<p align="center"><b>ATIVO: '.$descricao_ativo.'</b></p>');

$ameacas= explode("*",$conteudo);

for ($x = 0; $x < count($ameacas); $x++){
	$ameaca_vunerabilidades= explode("%",$ameacas[$x]);
	for ($y = 0; $y < (count($ameaca_vunerabilidades)-1); $y++){
		if($y==0){
			$pdf->WriteHTML('<br><p align="left"><b>Ameaça: </b>'. $ameaca_vunerabilidades[$y].'</p>');
			$pdf->WriteHTML('<br><p align="left"><b>			Vunerabilidade(s) existente(s): </b></p>');		
		}else{
			$pdf->WriteHTML('<br><p align="left">							-'.$ameaca_vunerabilidades[$y].'</p>');

		}		
	}
	$pdf->WriteHTML('<br>');
	
}

$pdf->WriteHTML('<br><br><p align="left"><b>Risco do ativo: '.$valor_risco.'</b></p><br>');
$pdf->WriteHTML('<p align="left"><b>Risco do ativo: '.$risco_qualitativo.'</b></p><br><br>');
date_default_timezone_set("America/Sao_Paulo");
$data= date("d/m/Y");
$hora= date("h:i:sa");
$as= utf8_decode('às'); 
$pdf->Cell(40,10, 'Analise realizada e salva em '.$data.' '.$as.' '.$hora);

//grava pdf no banco
$content = $pdf->Output("", "S"); //coloca conteudo do pdf em uma variavel string
$sql_grava_pdf = "insert into relatorio(relatorio,valor_risco) values('".addslashes($content)."',$valor_risco)";
$result= mysqli_query($conexao,$sql_grava_pdf);

if($result){
	
	$sql =   "SELECT MAX(id_relatorio) from relatorio";
	$resultado = mysqli_query($conexao,$sql);
	$row = mysqli_fetch_array($resultado);
	$id_relatorio = $row[0];

	$sql =        "INSERT INTO `ativo_relatorio` ";
	$sql = $sql . "(`id_relatorio`,`id_ativo`) ";
	$sql = $sql . "VALUES ('$id_relatorio','$id_ativo')";
	$result_ativo_relatorio = mysqli_query($conexao,$sql);

	if($result_ativo_relatorio){
		echo 'SUCESSO: Relatório salvo no banco de dados.';
		
		echo'<form action="ativo_lista.php" method="POST" style="margin-top: 20px">';
					echo'<div class="form-group">';
					echo'<td> <button type="submit" id="botao" class="btn btn-primary botao">Voltar para lista de Ativos </button><td>'; 
					echo'<input type="hidden" name="id_processo" value='. $id_processo .' >';
					echo'<input type="hidden" name="id" value='. $id .' >';
					echo'</form>';
					echo '</tr>';
					
	}else{
		echo 'ERRO: Falha ao gravar relatorio no banco de dados.(result_ativo_relatorio) ';	
	} 


}else{
	echo 'ERRO: Falha ao gravar relatorio no banco de dados.(result_relatorio)';
}


?>