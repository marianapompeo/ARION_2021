<?php
	session_start();
	
	//Incluindo a conexão com banco de dados
	include("conexao.php");

	//O campo usuário e senha preenchido entra no if para validar
	if((isset($_POST['email'])) && (isset($_POST['senha']))){		
		$email = mysqli_real_escape_string($conexao, $_POST['email']);
		$senha = mysqli_real_escape_string($conexao, $_POST['senha']);
		$senha = md5($senha);
		//header('Content-Type: text/plain');
		//echo "SENHA ".$senha;
		//Buscar na tabela
		$result_usuario = ("select * from usuario WHERE email='$email' AND senha = '$senha'");
			
			$resultado_usuario = mysqli_query($conexao, $result_usuario);

			$resultado = mysqli_fetch_assoc($resultado_usuario);

			if(isset($resultado)){
			$_SESSION['usuarioId'] = $resultado['id'];
			$_SESSION['usuarioSenha'] = $resultado['senha'];
			$_SESSION['usuarioEmail'] = $resultado['email'];


		header("Location:depois-login.php");
	}
			else {
				$_SESSION['loginErro'] = "Usuario ou Senha inválido";
				header("Location: index.html");
				
			}}

			else {
				$_SESSION['loginErro'] = "Usuario ou Senha inválido";
				header("Location: index.html");
			}
		

		?>	


