
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include('conexao.php');

// dados do formulário anterior
$nome=$_POST['nome'];
$email=$_POST['email'];
$cpf=$_POST['cpf'];
$senha=$_POST['senha'];
$cargo=$_POST['cargo'];

// salva os dados do formulário no banco de dados na tabela 'usuario'
$senha = mysqli_real_escape_string($conexao, $senha);
$senha = md5($senha);
$sql =        "INSERT INTO `usuario` ";
$sql = $sql . "(`nome`, `email`, `cpf`, `senha`, `cargo`) ";
$sql = $sql . "VALUES ('$nome','$email','$cpf','$senha','$cargo')";
$inserir = mysqli_query($conexao,$sql); 
    //header('Content-Type: text/plain');
    //echo "SENHA ".$senha;
?>

<html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ARION</title>
  <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="assets/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="assets/css/sb-admin.min.css">
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Arsha - v2.3.1
  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.html">ARION</a></h1> 
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="index.html">Página Inicial</a></li>
          <li><a href="#sobreprojeto">Sobre o Projeto</a></li>
          <li><a href="#dicas">Dicas de Segurança</a></li>
          <li><a href="#time">Time</a></li>
          <li><a href="#contact">Contato</a></li>
           </nav><!-- .nav-menu --> 
  
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <ol>
          <li><a href="index.html">Home</a></li>
          <li>Cadastro de Usuário</li>
        </ol>
        <h2>Cadastro de Usuário</h2>

      </div>
    </section><!-- End Breadcrumbs -->


    <section class="inner-page">
      <div class="container">
    <div style="text-align: center">    
		<h4> Usuário cadastrado! Volte para página inicial e faça o login!</h4>
	</div></div>
	<center>


      
    </section>

  </main><!-- End #main -->
    <div style="text-align: center">    
		<a href="index.html" role="button" class="btn btn-sm btn-primary">Voltar para Página Inicial</a> </div>
		
	</center> 
</body>
</html>
