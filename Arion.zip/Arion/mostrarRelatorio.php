<!DOCTYPE html>
<html>
<head>
<title>Relatórios</title>
<style>
table {
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th {
  cursor: pointer;
}

th, td {
  text-align: left;
  padding: 16px;
}

tr:nth-child(even) {
  background-color: #f2f2f2
}
</style>
</head>
<body>
<script>
  function get_id_relatorio_baixar(id_relatorio){
    //console.log('debug: entrou baixar');
    document.getElementById("id_relatorio_baixar").value= id_relatorio;
  }

  function get_id_relatorio_excluir(id_relatorio){
    document.getElementById("id_relatorio_excluir").value= id_relatorio;
  }
</script>
  <?php
session_start();
$id_usuario= $_SESSION['usuarioId'];
//require('./fpdf/fpdf.php');
require('./fpdf/WriteHTML.php');
include('conexao.php');

/*
//header_remove();
if (isset($_POST['id_relatorio_baixar']) && $_POST['id_relatorio_baixar'] != '') {    

  $sql = "select * from relatorio where id_relatorio =".$_POST['id_relatorio_baixar'];
  $result = mysqli_query($conexao,$sql);
  $rs = mysqli_fetch_assoc($result);
  $content = $rs['relatorio'];

  header('Content-Type: application/pdf');
  header("Content-Length: ".strlen($content));
  header('Content-Disposition: attachment; filename=relatorio.pdf');
  //echo 'PARAMETRO= '.$q;
  print $content;
}


//codigo para excluir relatorio
if (isset($_POST['id_relatorio_excluir']) && $_POST['id_relatorio_excluir'] != '') {
    //echo "Essa variável existe.";

  $sql = "DELETE FROM ativo_relatorio WHERE id_relatorio =".$_POST['id_relatorio_excluir'];
  $result_ativo_relatorio = mysqli_query($conexao,$sql);

  $sql = "DELETE FROM relatorio WHERE id_relatorio =".$_POST['id_relatorio_excluir'];
  $result_relatorio = mysqli_query($conexao,$sql); 

  header("Location: mostrarRelatorio.php");
}
*/
echo '<div style="text-align: center">
<p><strong><h2>Relatórios</h2></strong></p> 
</div>';

$sql_relatorios= "SELECT em.nomefantasia, proc.descricao, atv.descricao_ativo, at_tipo.descricao_tipo_ativo, rel.valor_risco, rel.data_hora, rel.relatorio, usuario.id, rel.id_relatorio  from usuario, empresa as em, processo as proc, ativo as atv, tipo_ativo as at_tipo, empresa_processo as emproc, processo_ativo as procativo, relatorio as rel, ativo_relatorio as atrel where em.id=emproc.id_empresa AND emproc.id_processo=proc.id_processo AND atv.id_ativo=procativo.id_ativo AND procativo.id_processo= proc.id_processo AND atrel.id_ativo=atv.id_ativo AND rel.id_relatorio=atrel.id_relatorio AND atv.id_tipo_ativo=at_tipo.id_tipo_ativo AND em.id_usuario=usuario.id AND usuario.id= $id_usuario";

echo '<form action= "baixarRelatorio.php" method="POST">';
echo '<table id="myTable">';
echo '<tr> 
    <th onclick="sortTable(0)">Empresa</th>
    <th onclick="sortTable(1)">Processo</th>
    <th onclick="sortTable(2)">Ativo</th>
    <th onclick="sortTable(3)">Tipo de Ativo</th>
    <th onclick="sortTable(4)">Risco</th>
    <th onclick="sortTable(5)">Data/Hora</th>
    <th onclick="sortTable(6)">Relatório</th>
    <th onclick="sortTable(7)">Excluir Relatório</th>
    </tr>';

$buscaRelatorios = mysqli_query($conexao,$sql_relatorios);
while ($relatorio = mysqli_fetch_array($buscaRelatorios)) { 
    echo '<tr>';
    echo '<td>'.$relatorio[0].'</td>';
    echo '<td>'.$relatorio[1].'</td>';
    echo '<td>'.$relatorio[2].'</td>';
    echo '<td>'.$relatorio[3].'</td>';
    echo '<td>'.$relatorio[4].'</td>';
    echo '<td>'.$relatorio[5].'</td>';
    echo '<td><input type="submit" onclick="get_id_relatorio_baixar('.$relatorio[8].')" value="Baixar Relatório"></td>';
    echo '<td><input type="submit" onclick="get_id_relatorio_excluir('.$relatorio[8].')" value="Excluir Relatório"></td>';    
    echo '</tr>';  
}
echo '</table>';
    echo '<input type="hidden" id="id_relatorio_baixar" name="id_relatorio_baixar" value="">'; 
    echo '<input type="hidden" id="id_relatorio_excluir" name="id_relatorio_excluir" value="">'; 
    echo '</form>';
                  
?>

<script>
//recebe data formato dd-mm-aaaa e devolve aaaa-mm-dd
function FormataStringData(stringData) {
  data= stringData.split(" ")[0];
  hora= stringData.split(" ")[1];
  
  var dia  = data.split("-")[0];
  var mes  = data.split("-")[1];
  var ano  = data.split("-")[2];

  dataAjustada= ano + '-' + ("0"+mes).slice(-2) + '-' + ("0"+dia).slice(-2); 
  return dataAjustada+' '+hora;
}

function sortTable(n) {
  var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
  table = document.getElementById("myTable");
  switching = true;
  //Set the sorting direction to ascending:
  dir = "asc"; 
  /*Make a loop that will continue until
  no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
    first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
      one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[n];
      y = rows[i + 1].getElementsByTagName("TD")[n];
      /*check if the two rows should switch place,
      based on the direction, asc or desc:*/
      if (dir == "asc") {
        if(n == 5){  // aqui mudei era 5
        	if (Date.parse(FormataStringData(x.innerHTML)) > Date.parse(FormataStringData(y.innerHTML))) {
          			//if so, mark as a switch and break the loop:
          			shouldSwitch= true;
          			break;
        		}
        }else{
        		    if(n == 4){
                    if (parseInt(x.innerHTML) > parseInt(y.innerHTML)) {
                      //if so, mark as a switch and break the loop:
                      shouldSwitch= true;
                      break;
                    }
                }else{
                    if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                      //if so, mark as a switch and break the loop:
                      shouldSwitch= true;
                      break;
                    }  
                }
            

             }
      } else if (dir == "desc") {
        if(n == 5){ // aqui mudei era 5
        	if (Date.parse(FormataStringData(x.innerHTML)) < Date.parse(FormataStringData(y.innerHTML))) {
          			//if so, mark as a switch and break the loop:
          			shouldSwitch= true;
          			break;
        		}
        }else{
                if(n == 4){
                    if (parseInt(x.innerHTML) < parseInt(y.innerHTML)) {
                      //if so, mark as a switch and break the loop:
                      shouldSwitch= true;
                      break;
                    }
                }else{
                    if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                      //if so, mark as a switch and break the loop:
                      shouldSwitch= true;
                      break;
                    }  
                }
             }
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      //Each time a switch is done, increase this count by 1:
      switchcount ++;      
    } else {
      /*If no switching has been done AND the direction is "asc",
      set the direction to "desc" and run the while loop again.*/
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}
</script>
      <div style="text-align: right">
        <form action="depois-login.php" method="POST" style="margin-top: 20px">
          <div class="form-group">
          <div style="text-align: center">  
          <button type="submit" id="botao" class="btn btn-primary botao">Voltar </button>

          </form>      </div>

</body>
</html>
