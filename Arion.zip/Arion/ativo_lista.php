
<html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ARION</title>
  <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="assets/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="assets/css/sb-admin.min.css">
  
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Arsha - v2.3.1
  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
   <header id="header" class="fixed-top header-inner-pages">
    <div class="container d-flex align-items-center">

      <h1 class="logo mr-auto"><a href="index.html">ARION</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="index.html">Página Inicial</a></li>
          <li><a href="#">Sobre o Projeto</a></li>
          <li><a href="#">Dicas de Segurança</a></li>
          <li><a href="#">Time</a></li>
          <li><a href="#">Contato</a></li>

        </ul>
      </nav><!-- .nav-menu -->

      <a href="sair.php" class="get-started-btn scrollto">Sair</a>

    </div>
     </div>
  </header> <!-- End Header -->
   
	<div class="container" style="margin-top: 40px">
	<br> <br> <br>
		<table class="table">
			<thead>
				<tr>
				
					<th scope="col">Id_Ativo</th>
					<th scope="col">Descrição</th>
					<th scope="col">Valor</th>
					<th scope="col">Tipo</th>
					<th scope="col">Id_processo</th>
					<th> </th>
					<th> </th>
					<th> </th>			
				</tr>
			</thead>
			<tbody>
				<tr>
					<?php
					
					session_start();
					include('conexao.php');
					
					$id_processo= $_POST['id_processo'] ;
					//echo $id_processo;


					$id= $_POST['id'] ;
					//echo $id;


          			$id_usuario=$_SESSION['usuarioId'];

					
					$sql = "select ativo.id_ativo, ativo.descricao_ativo, ativo.valor_ativo, ativo.id_tipo_ativo,		processo.id_processo 
							from ativo, processo, processo_ativo 
							where processo_ativo.id_ativo = ativo.id_ativo
							AND processo.id_processo = processo_ativo.id_processo 
							AND processo.id_processo = $id_processo";

					$busca = mysqli_query($conexao,$sql);
					if(mysqli_num_rows($busca) > 0){
						//echo 'Achou ativos';

						while ($array = mysqli_fetch_array($busca)) {

							$id_ativo = $array[0];
							$descricao_ativo = $array[1];
							$valor_ativo = $array[2];
							$id_tipo_ativo = $array[3];
							$id_processo = $array[4];

					
							echo '<td>' . $id_ativo . '</td>';
							echo '<td>' . $descricao_ativo . '</td>';
							echo '<td>' . $valor_ativo . '</td>';
							echo '<td>' . $id_tipo_ativo . '</td>';
							echo '<td>' . $id_processo . '</td>';

							echo '<form action="ameacas.php" method="POST" style="margin-top: 20px">';
							echo '<div class="form-group">';
							echo '<td> <button type="submit" id="botao" class="btn btn-primary botao">Selecionar Ativo </button><td>';
							echo '<input type="hidden" name="id_tipo_ativo" value=' . $id_tipo_ativo .'>';
							echo '<input type="hidden" name="id_processo" value=' . $id_processo .'>';
							echo '<input type="hidden" name="id_ativo" value=' . $id_ativo .'>';
							echo '<input type="hidden" name="id" value=' . $id .'>';
							echo '<input type="hidden" name="id_usuario" value=' . $id_usuario .'>';

							echo '</form>';
							echo '</tr>';

							
							
						}
									}					
					

					
					?>

				</tr>
				
			</tbody>
		</table>
		

      <div style="text-align: center">
        <form action="cadastroativo.php" method="POST" style="margin-top: 20px">
					<div class="form-group">
					<button type="submit" id="botao" class="btn btn-primary botao">Cadastrar Ativo </button>
					<input type="hidden" name="id_processo" value=<?php echo $id_processo; ?> >
					<input type="hidden" name="id" value=<?php echo $id; ?> >
					</form>
			
      <div style="text-align: right">
        <form action="processo_lista.php" method="POST" style="margin-top: 20px">
					<div class="form-group">
					<button type="submit" id="botao" class="btn btn-danger botao">Voltar para lista de Processos </button>
					<input type="hidden" name="id" value=<?php echo $id; ?> >
					</form>      </div>

      
      <div style="text-align: right">
        <form action="depois-login.php" method="POST" style="margin-top: 20px">
					<div class="form-group">
					<button type="submit" id="botao" class="btn btn-danger botao">Voltar Menu Inicial </button>
					<input type="hidden" name="id_usuario" value=<?php echo $id_usuario; ?> >
					</form>      </div>

      
	</div>
	
  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

    <script src="assets/jquery/jquery.min.js"></script>


</body>
</html>
