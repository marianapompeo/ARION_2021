<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include('conexao.php');
$id_usuario=$_SESSION['usuarioId']; 

//echo $id_usuario;

//retorna todos os id de relatorios do usuario para EXCLUIR RELATORIOS
$sql = "select relatorio.id_relatorio FROM empresa, processo, empresa_processo, processo_ativo, ativo, ativo_relatorio, relatorio WHERE empresa_processo.id_processo = processo.id_processo AND empresa_processo.id_empresa = empresa.id AND processo_ativo.id_processo = processo.id_processo AND processo_ativo.id_ativo = ativo.id_ativo AND ativo_relatorio.id_ativo = ativo.id_ativo AND ativo_relatorio.id_relatorio = relatorio.id_relatorio AND empresa.id_usuario =$id_usuario" ;

$id_relatorios = mysqli_query($conexao,$sql);
if(mysqli_num_rows($id_relatorios) > 0){
		//echo 'Achou relatorios';
	while ($array = mysqli_fetch_array($id_relatorios)) {
		$sql_deleta_relatorio = "DELETE FROM relatorio WHERE relatorio.id_relatorio= $array[0]";
		$sql_deleta_ativo_relatorio = "DELETE FROM ativo_relatorio WHERE ativo_relatorio.id_relatorio= $array[0]";

		 if(!mysqli_query($conexao,$sql_deleta_ativo_relatorio)){
		 	echo "erro na exclusao do ativo_relatorio ID ".$array[0];
		 }	

		 if(!mysqli_query($conexao,$sql_deleta_relatorio)){
		 	echo "erro na exclusao do relatorio ID ".$array[0];
		 }	 
	}
}

//retorna todos os ids de ativos do usuario para EXCLUIR ATIVOS	
$sql = "select ativo.id_ativo FROM empresa, processo, empresa_processo, processo_ativo, ativo WHERE empresa_processo.id_processo = processo.id_processo AND empresa_processo.id_empresa = empresa.id AND processo_ativo.id_processo = processo.id_processo AND processo_ativo.id_ativo = ativo.id_ativo AND empresa.id_usuario =$id_usuario";	

$id_ativos = mysqli_query($conexao,$sql);
if(mysqli_num_rows($id_ativos) > 0){
		//echo 'Achou ativos';
	while ($array = mysqli_fetch_array($id_ativos)) {
		$sql_deleta_processo_ativo = "DELETE FROM processo_ativo WHERE processo_ativo.id_ativo= $array[0]";
		$sql_deleta_ativo = "DELETE FROM ativo WHERE ativo.id_ativo= $array[0]";		

		 if(!mysqli_query($conexao,$sql_deleta_processo_ativo)){
		 	echo "erro na exclusao do processo_ativo ID ".$array[0];
		 }	

		 if(!mysqli_query($conexao,$sql_deleta_ativo)){
		 	echo "erro na exclusao do ativo ID ".$array[0];
		 }	 
	}
}

//retorna todos os ids de processos do usuario para EXCLUIR PROCESSOS
$sql = "select processo.id_processo FROM empresa, processo, empresa_processo WHERE empresa_processo.id_processo = processo.id_processo AND empresa_processo.id_empresa = empresa.id AND empresa.id_usuario =$id_usuario";

$id_processos = mysqli_query($conexao,$sql);
if(mysqli_num_rows($id_processos) > 0){
		//echo 'Achou processos';
	while ($array = mysqli_fetch_array($id_processos)) {
		$sql_deleta_empresa_processo = "DELETE FROM empresa_processo WHERE empresa_processo.id_processo= $array[0]";
		$sql_deleta_processo = "DELETE FROM processo WHERE processo.id_processo= $array[0]";		

		 if(!mysqli_query($conexao,$sql_deleta_empresa_processo)){
		 	echo "erro na exclusao do empresa_processo ID ".$array[0];
		 }	

		 if(!mysqli_query($conexao,$sql_deleta_processo)){
		 	echo "erro na exclusao do processo ID ".$array[0];
		 }	 
	}
}

//retorna todos os ids de empressas do usuario para EXCLUIR EMPRESAS
$sql = "select empresa.id FROM empresa WHERE empresa.id_usuario= $id_usuario";

$id_empresas = mysqli_query($conexao,$sql);
if(mysqli_num_rows($id_empresas) > 0){
		//echo 'Achou empresas';
	while ($array = mysqli_fetch_array($id_empresas)) {
		$sql_empresa = "DELETE FROM empresa WHERE empresa.id= $array[0]";		

		 if(!mysqli_query($conexao,$sql_empresa)){
		 	echo "erro na exclusao da empresa ID ".$array[0];
		 }	 
	}
}


//retorna o id do usuário para EXCLUIR USUÁRIO
$sql = "select usuario.id FROM usuario WHERE usuario.id= $id_usuario";

$id_usuarios = mysqli_query($conexao,$sql);
if(mysqli_num_rows($id_usuarios) > 0){
		//echo 'Achou usuarios';
	while ($array = mysqli_fetch_array($id_usuarios)) {
		$sql_usuarios = "DELETE FROM usuario WHERE usuario.id= $array[0]";		

		 if(!mysqli_query($conexao,$sql_usuarios)){
		 	echo "erro na exclusao do usuario ID ".$array[0];
		 }	 
	}
}

?>

<html>
<head>
	<meta charset="utf-8">
	<title>Exclusão de Cadastro de Usuários</title>  
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

	<div class="container" style="widht: 500px;margin-top: 20px">
		<h4>Usuario excluído com sucesso</h4>
	</div>
	<div class="form-group">
    <a href="index.html" role="button" class="btn btn-sm btn-primary">Página Inicial Arion </a> 
</body>
</html>
