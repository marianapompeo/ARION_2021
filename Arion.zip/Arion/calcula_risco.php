<?php
					
					session_start();
					include('conexao.php');
						

					$id_tipo_ativo= $_POST['id_tipo_ativo'] ;
					$id_processo= $_POST['id_processo'] ;
					$id_ativo= $_POST['id_ativo'] ;
					echo $id_tipo_ativo .' - '. $id_processo . ' - ' . $id_ativo ;
	
					
					
?>