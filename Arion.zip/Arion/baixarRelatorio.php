<?php
	session_start();
	$id_usuario= $_SESSION['usuarioId'];
	//require('./fpdf/fpdf.php');
	require('./fpdf/WriteHTML.php');
	include('conexao.php');

$id_relatorio_baixar= $_POST['id_relatorio_baixar'];
$id_relatorio_excluir= $_POST['id_relatorio_excluir'];

if($id_relatorio_baixar != ""){
	$sql = "select * from relatorio where id_relatorio =".$id_relatorio_baixar;
 	$result = mysqli_query($conexao,$sql);
  	$rs = mysqli_fetch_assoc($result);
  	$content = $rs['relatorio'];

  	header('Content-Type: application/pdf');
  	header("Content-Length: ".strlen($content));
  	header('Content-Disposition: attachment; filename=relatorio.pdf');
  	//echo 'PARAMETRO= '.$q;
  	print $content;
}

if($id_relatorio_excluir != ""){
	$sql = "DELETE FROM ativo_relatorio WHERE id_relatorio =".$id_relatorio_excluir;
  	$result_ativo_relatorio = mysqli_query($conexao,$sql);

  	$sql = "DELETE FROM relatorio WHERE id_relatorio =".$id_relatorio_excluir;
  	$result_relatorio = mysqli_query($conexao,$sql); 

  	header("Location: mostrarRelatorio.php");	
}

?>