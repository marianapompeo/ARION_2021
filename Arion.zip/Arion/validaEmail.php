
<?php

session_start(); //inicia sessão

//código que reporta todos os erros php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1); 
error_reporting(E_ALL); 


include('conexao.php'); // faz conexão com banco de dados

$email = $_POST['email']; // pego o email digitado na página anterior e comparo, se já houver esse email no banco então já existe cadastro e vai para página com mensagem, se não houver esse email no banco vou para a próxima pagina do cadastro (continuacadastro.php)


	//O campo email preenchido entra no if para validar
	if((isset($_POST['email'])) ){
		$email = mysqli_real_escape_string($conexao, $_POST['email']);

		//Buscar na tabela
		$result_usuario = ("select * from usuario WHERE email='$email'");
			
			$resultado_usuario = mysqli_query($conexao, $result_usuario);

			$resultado = mysqli_fetch_assoc($resultado_usuario);

			if(isset($resultado)){
			$_SESSION['usuarioId'] = $resultado['id'];
			$_SESSION['usuarioEmail'] = $resultado['email'];

			$_SESSION['cadastroErro'] = "Email já cadastrado";
			header("Location: msgcadastrado.html");

	}
			else { 

				$_SESSION['cadastroCerto'] = "Continue o Cadastro";
				$_SESSION['usuarioEmail']= $email;
				header("Location: continuacadastro.php");
				
				
			}}

			else {
				$_SESSION['cadastroCerto'] = "Continue o Cadastro";
				header("Location: continuacadastro.php");
				}
		

		?>	
