<!DOCTYPE html>
<html>
<head>
	<title>ARION</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	<script src="https://kit.fontawesome.com/14e3cc8fa2.js" crossorigin="anonymous"></script>

</head>
<body>
<?php 
					session_start();
					include('conexao.php');
					
					$id_tipo_ativo= $_POST['id_tipo_ativo'] ;
					$id_processo= $_POST['id_processo'] ;
					$id_ativo= $_POST['id_ativo'] ;
          $id= $_POST['id'] ;
					//echo $id_tipo_ativo .' - '. $id_processo . ' - ' . $id_ativo  ;
					
          //pega valor do processo
					$sql_peso_processo= "select valor_processo from processo where id_processo=$id_processo";
					$busca_valor_processo = mysqli_query($conexao,$sql_peso_processo);
					$result = mysqli_fetch_array($busca_valor_processo);
					$valor_processo = $result[0];

          //pega valor do ativo
					$sql_valor_ativo= "select valor_ativo, descricao_ativo from ativo where id_ativo=$id_ativo";
					$busca_valor_ativo = mysqli_query($conexao,$sql_valor_ativo);
					$result = mysqli_fetch_array($busca_valor_ativo);
					$valor_ativo = $result[0];
					$descricao_ativo = $result[1];
?>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script>
//recebe um valor referente ao risco e devolve a analise qualitativa do risco
function analiseQualitativa(valor_risco){
  
  if(valor_risco >=0 && valor_risco <=25){return "Risco Muito Baixo"}
  if(valor_risco >=26 && valor_risco <=40){return "Risco Baixo"}
  if(valor_risco >=41 && valor_risco <=60){return "Risco Moderado"}
  if(valor_risco >=61 && valor_risco <=100){return "Risco Alto"}
  if(valor_risco >100){return "Risco Muito Baixo"}  

}

//recebe um coeficiente de vunerabilidade para uma determinada ameaca
//retorna 0 caso o valor de entrada nao esteja dentro da faixa de 0 a 100
function calculaProbabilidade(coeficiente){
	if(coeficiente >=0 && coeficiente <=20){ return 1}
    
    if(coeficiente >=21 && coeficiente <=41){ return 2}
    
    if(coeficiente >=42 && coeficiente <=62){ return 3}
    
    if(coeficiente >=63 && coeficiente <=84){ return 4}
    
    if(coeficiente >=85 && coeficiente <=100){ return 5}
    
    return 0
}
//calcula risco do ativo
function calcula() {  
	//variaveis
    var valor_Processo=<?php print $valor_processo; ?>;
    var valor_Ativo=<?php print $valor_ativo; ?>;    
    var riscos=[];
    var resultado="";//usado somente para dar o resultado
    var vunerabilidades_checked="";
    var pdf="";
    
    console.log( document.getElementById("descricao_ativo").value );

    //Pega todas as tables, pois cada table representa uma ameaca
  	var ameacasTable= document.getElementsByTagName("table");
    //percorre as ameacas
    for(let i = 0; i < ameacasTable.length; i++){
    	somaVunerabilidades=0;    	
    	//pega o valor do impacto da ameaca
        objSelectImpacto= ameacasTable[i].getElementsByTagName("select");
        
        valor_Impacto_Ameaca= objSelectImpacto[0].value;       
        
		//nome da ameaca
        nomeAmeaca= (ameacasTable[i].getElementsByTagName("td"))[0].innerHTML;        
        
        //percorre vunerabilidades e soma
        vunerabilidades= ameacasTable[i].getElementsByTagName("input");
        
        for(let x = 0; x < vunerabilidades.length; x++){
        	if(vunerabilidades[x].checked){
            	somaVunerabilidades= somaVunerabilidades +1;
            	vunerabilidades_checked= vunerabilidades_checked+vunerabilidades[x].value+"%";
            }
        }
        
        //calcula coeficiente do incidente
        coeficiente= (somaVunerabilidades*100)/vunerabilidades.length;
        
        //calcula probabilidade do incidente
        probalidadeIncidente= calculaProbabilidade(coeficiente);
        
        //calcula risco
        risco= probalidadeIncidente * valor_Impacto_Ameaca * valor_Processo * valor_Ativo;       
        
        //adiciona os riscos calculados em um array
        riscos.push(risco);
        
        if(vunerabilidades_checked.length > 0){
        	pdf= pdf+nomeAmeaca+"%"+vunerabilidades_checked+"*";        	
        }

        //contatena os resultados para apresentar
        nomeAmeaca= ameacasTable[i].getElementsByTagName("td");
        resultado= resultado+"Risco da Ameaça "+nomeAmeaca[0].innerHTML+" => "+risco+"<br>";
    	vunerabilidades_checked="";
    }
    	//ordena array de riscos do menor para o maior
        riscos.sort(function(a, b){return a - b});
        resultado= resultado+"<br>RISCO DO ATIVO => "+riscos[riscos.length-1];
        riscoQualitativo= analiseQualitativa(riscos[riscos.length-1]);

      document.getElementById("risco").innerHTML= "RISCO DO ATIVO = "+riscos[riscos.length-1]+"<br>RISCO QUALITATIVO = "+riscoQualitativo;
      document.getElementById("risco_qualitativo").value= '"'+riscoQualitativo+'"';       
    	document.getElementById("pdf").value= pdf;
    	document.getElementById("valor_risco").value= riscos[riscos.length-1];

}
</script>

	<div class="container" style="margin-top: 40px">
		<h5 style="padding-bottom: 40px">Na coluna "Vulnerabilidades", marque as que você identificar como existente. <br>
    Na coluna Impacto da Ameaça dê uma nota. Essa nota refere-se à ameaça, considere que esta vire um inciente real na empresa. A nota serve para identificarmos o quanto a sua empresa seria impactada. As notas possíveis e o que significam são as seguintes:</h5> 

    <h6 style="padding-bottom: 40px">
    1 - Insignificante (nenhum prejuízo na imagem, perdas financeiras irrelevantes, sem impactos sobre os negócios) <br>
    2 - Menor (pequenos efeitos e facilmente reparados, solução imediata local, perdas financeiras médias) <br>
    3 - Moderado (efeito sobre algumas atividades de negócios, possui solução com ajuda externa, perdas financeiras moderadas) <br>
    4 - Maior (grandes abalos na imagem, interrupção temporária da atividade de negócio, ajuda externa para tratamento, perdas financeiras elevadas)<br>
    5 - Catastrófico (morte, interrupção total das atividades, solução externa, danos de difícil reparação, perdas financeiras elevadas)</h6> <br>
    
					<?php	

					$sql_ameacas= "select * from ameaca where id_tipo_ativo=$id_tipo_ativo";
					$buscaAmeacas = mysqli_query($conexao,$sql_ameacas);

            		while ($ameacas = mysqli_fetch_array($buscaAmeacas)) {            			
            			            			
            			echo '<table class="table table-bordered">  
            			<thead>';
            			echo '  
    							<th>Ameaca</th>
    							<th>Impacto da Ameaça</th>
    							<th>Vunerabilidades</th>
    							<th>Marcar</th>
  							</thead></td></tr>'; 

  						echo '<tbody>';	
  					  	echo '<tr>';
    					echo '<td>'. $ameacas[1] .'</td>';
   			 			echo '<td>
    							<select name="impacto_ameaca">
  									<option value="1">1 - Insignificante</option>
  									<option value="2">2 - Menor </option>
  									<option value="3">3 - Moderado </option>
  									<option value="4">4 - Maior</option>
                    <option value="5">5 - Catastrófico</option>
								</select>
    						</td>';

    					$sql_vulnerabilidades= "select descricao_vulnerabilidade  
    											from ameaca_vulnerabilidade as av, vulnerabilidade as v 
    											where av.id_vulnerabilidade=v.id_vulnerabilidade AND 
    											av.id_ameaca=$ameacas[0]";

						$buscaVulnerabilidades = mysqli_query($conexao,$sql_vulnerabilidades);

          				$flag_vulnerabilidade=0;
          				while ($vulnerabilidades = mysqli_fetch_array($buscaVulnerabilidades)) {
          					if($flag_vulnerabilidade == 0){
          						echo '<td> <label>' . $vulnerabilidades[0] . '</label> </td>
    							<td> <input type="checkbox" value="'. $vulnerabilidades[0] .'"> </td>';
    							echo '</tr>';
    							$flag_vulnerabilidade= $flag_vulnerabilidade+1;
          					}else{
          						echo '<tr>';
          						echo '<td></td><td></td>';
          						echo '<td> <label>' . $vulnerabilidades[0] . '</label> </td>
    							<td> <input type="checkbox" value="'. $vulnerabilidades[0] .'"> </td>';
    							echo '</tr>';
          					}          					
          				}  				

  						echo '</tbody></table><br></br>'; 

  					} 		                 		

					?>	
				  <div style="text-align: center">
       				<button class="btn btn-primary botao" onclick="calcula()">Cacular</button> 
       		<form action="gerapdf.php" method="POST" style="margin-top: 20px">
					<div class="form-group">
					<button type="submit" id="botao" onclick="calcula()" class="btn btn-primary botao">Gravar relatório </button>
					<input type="hidden" name="id_tipo_ativo" value=<?php echo $id_tipo_ativo ?>>
					<input type="hidden" name="id_processo" value=<?php echo $id_processo ?> >
					<input type="hidden" name="id_ativo" value=<?php echo $id_ativo ?> >
					<input type="hidden" id="descricao_ativo" name="descricao_ativo" value="<?php print $descricao_ativo; ?>" >
					<input type="hidden" id="pdf" name="pdf" >	
					<input type="hidden" id="valor_risco" name="valor_risco" >
          <input type="hidden" id="risco_qualitativo" name="risco_qualitativo" >
          <input type="hidden" name="id" value= <?php echo $id?> >			
					</form>
					
					<br><br><p id="risco"></p>		
		      <div style="text-align: right">
		    <form action="ativo_lista.php" method="POST" style="margin-top: 20px">';
				<div class="form-group">
				<td> <button type="submit" id="botao" class="btn btn-danger botao">Voltar para lista de Ativos </button><td>
				<input type="hidden" name="id_processo" value= <?php echo $id_processo?> >
        <input type="hidden" name="id" value= <?php echo $id?> >
				</form>
			    </tr>
    <div class="container" style="margin-top: 40px">
    <div style="text-align: left"> 
    <h6 style="padding-bottom: 40px">Valores de Riscos Qualificados: <br>
      0 - 25 = Risco Muito Baixo <br>
      26 - 40 = Risco Baixo <br>
      41 - 60 = Risco Moderado <br>
      61 - 100 = Risco Alto <br>
      Acima de 100 = Risco Muito Alto <br>
    </h6> 

             
	</div>


</body>
</html>